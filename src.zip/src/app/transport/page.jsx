import Link from "next/link"
export default function Transport(){
    return(
    <section className="text-center mt-6">
       <h2 className="text-2xl font-bold text-black/80">All Transport Services</h2>
           <div className="grid md:grid-cols-2 lg:grid-cols-2 w-[95%] backdrop-blur-sm bg-slate-100 m-6  p-4">

            <Link href="/transport/tt" className="m-auto hover:opacity-[0.95] hover:scale-105 duration-300">
            <div className="relative shadow-xl w-[20rem] rounded-md h-[20rem] my-6 bg-white flex flex-col justify-center items-center ">
                <img src="/img/transport/tt.png" alt=""  className=" w-[15rem] h-[15rem]"/>
                <a href="" className=" text-2xl font-bold text-black z-10  hover:text-3xl">
                Truck & Tempo 
                </a>
            </div>
            </Link>
            <Link href="/transport/driver" className="m-auto hover:opacity-[0.95] hover:scale-105 duration-300">
            <div className="relative shadow-xl w-[20rem] rounded-md h-[20rem] my-6 bg-white flex flex-col justify-center items-center ">
                <img src="/img/Transport/driver.png" alt=""  className=" w-[15rem] h-[15rem]"/>
                <a href="" className=" text-2xl font-bold text-black z-10  hover:text-3xl">
                Driver
                </a>
            </div>
            </Link>
           </div>
    </section>
    )
}