import Image from "next/image";
import Banner from "./_components/Banner";
import Track from "./_components/Track";


export default function Home() {
  return (
    <>
       <Track />
    <Banner />
 
    </> 
  );
}
